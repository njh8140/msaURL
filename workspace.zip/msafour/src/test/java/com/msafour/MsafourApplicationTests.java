package com.msafour;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsafourApplicationTests {

	@Test
	void contextLoads() {
	}

}
