package com.msafour.prodinfo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.msafour.prodinfo.model.ProdinfoVO;

@Mapper
public interface ProdinfoMapper {

	List<ProdinfoVO> selectProdinfoList();
	void insertProdinfo(String prodcd, String prodnm);
	ProdinfoVO selectByProdcd(String prodcd);
	void deleteProdinfo(String prodcd);
	void updateProdinfo(String prodcd, String prodnm);
}