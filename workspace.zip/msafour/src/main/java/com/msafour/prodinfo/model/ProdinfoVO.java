package com.msafour.prodinfo.model;

public class ProdinfoVO {
	
	public String prodcd;
	public String prodnm;
	
}