package com.msaone.board.model;

public class UserVO {
	
	public String id;
	public String name;
	
}