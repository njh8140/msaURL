package com.msatwo.user.model;

public class UserVO {
	
	public String id;
	public String name;
	
}