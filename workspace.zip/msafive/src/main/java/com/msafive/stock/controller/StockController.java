package com.msafive.stock.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.msafive.stock.model.StockVO;
import com.msafive.stock.service.StockService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class StockController {
	
	@Autowired
	public StockService stockService;
	
	@RequestMapping(value="/form", method= {RequestMethod.GET, RequestMethod.POST}) //홈페이지용
	public ModelAndView form() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/stock/stockform");
		
		return mav;
	}
	
	@RequestMapping(value="/api/getform", method= {RequestMethod.GET, RequestMethod.POST}) 
	@ResponseBody
	public StockVO getform(@RequestBody StockVO uv) {
		StockVO uv2 = new StockVO();
		uv2 = stockService.getStock(uv.stockcd);
		
		return uv2;
	}
	
	
	@RequestMapping(value="/api/signup", method= {RequestMethod.GET, RequestMethod.POST}) //api 붙은 것들은 기능
	public void signup(@RequestBody StockVO uv) {
		System.out.println("stock stockcd ===> "+uv.stockcd);
		System.out.println("stock stocknm ===> "+uv.stocknm);
		stockService.saveStock(uv.stockcd, uv.stocknm);
	}
	
	@RequestMapping(value="/stocklist", method= {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView stocklist() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/stock/stocklist");
		
		return mav;
	}

	@RequestMapping(value="/api/list", method= {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public List<StockVO> list(){
		List<StockVO> list = stockService.getStockList();
		
		return list;
		
	}
	
	@RequestMapping(value="/api/update", method= {RequestMethod.GET, RequestMethod.POST}) 
	@ResponseBody
	public void update(@RequestBody StockVO uv) {
		stockService.updateStock(uv.stockcd, uv.stocknm);
	}
	
	@RequestMapping(value="/api/delete", method= {RequestMethod.GET, RequestMethod.POST}) 
	@ResponseBody
	public void delete(@RequestBody StockVO uv) {
		stockService.deleteStock(uv.stockcd);
	}
	
	@RequestMapping(value="/save", method= {RequestMethod.GET, RequestMethod.POST}) //save 연습
	public ModelAndView save() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/stock/stocksave");
		
		return mav;
	}
}