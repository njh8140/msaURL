package com.msafive.stock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.msafive.stock.mapper.StockMapper;
import com.msafive.stock.model.StockVO;

@Service
public class StockService {
	
	@Autowired
	public StockMapper stockMapper;
	
	public List<StockVO> getStockList(){
		return stockMapper.selectStockList();
	}
	
	public void saveStock(String stockcd, String stocknm) {
		stockMapper.insertStock(stockcd, stocknm);
	}
	
	public StockVO getStock(String stockcd) {
		return stockMapper.selectByStockcd(stockcd);
	}
	
	public void deleteStock(String stockcd) {
		stockMapper.deleteStock(stockcd);
	}
	
	public void updateStock(String stockcd, String stocknm) {
		stockMapper.updateStock(stockcd, stocknm);
	}
	
}