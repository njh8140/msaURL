package com.msafive.stock.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.msafive.stock.model.StockVO;

@Mapper
public interface StockMapper {

	List<StockVO> selectStockList();
	void insertStock(String stockcd, String stocknm);
	StockVO selectByStockcd(String stockcd);
	void deleteStock(String stockcd);
	void updateStock(String stockcd, String stocknm);
}